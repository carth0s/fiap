package br.com.fiap.jpa.dao;

import br.com.fiap.jpa.entity.Livro;

public interface LivroDAO extends GenericDAO<Livro, Long> {

}
