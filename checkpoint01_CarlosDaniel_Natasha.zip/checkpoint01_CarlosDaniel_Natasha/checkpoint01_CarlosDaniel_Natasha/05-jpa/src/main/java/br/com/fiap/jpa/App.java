package br.com.fiap.jpa;

import java.time.LocalDate;

import br.com.fiap.jpa.entity.Livro;
import br.com.fiap.jpa.service.impl.LivroServiceImpl;

public class App {

	public static void main(String[] args) {
		
		LivroServiceImpl livroService = LivroServiceImpl.getInstance();
		
		Livro livro1 = new Livro("Titulo 1", "Miyahara", "5", LocalDate.of(2005, 10, 1));
		Livro livro2 = new Livro("Titulo 2", "George Orwell", "3", LocalDate.of(1989, 02, 17));
		Livro livro3 = new Livro("Titulo 3", "Carlos", "4", LocalDate.of(2001, 7, 9));
		
		livroService.inserir(livro1);
		livroService.inserir(livro3);
		
		livroService.listar().forEach(System.out::println);
		
		livroService.remover(2L);
		
	}
}
